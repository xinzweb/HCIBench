from unittest import TestCase


class TestFioConfig(TestCase):

    def test___init__(self):
        # Todo
        pass
