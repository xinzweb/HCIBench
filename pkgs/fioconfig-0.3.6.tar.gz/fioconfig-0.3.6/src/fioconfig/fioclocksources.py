import inspect

from enum import Enum
from typeguard import typechecked
from typing import List


class FioClockSource(Enum):
    """ FIO Clock Sources
        Desc:   Use the given clocksource as the base of timing.
        Values: - gettimeofday: gettimeofday(2)
                - clock_gettime: clock_gettime(2)
                - cpu: Internal CPU clock source
        Ref.    https://fio.readthedocs.io/en/latest/fio_doc.html#time-related-parameters
        """
    cpu = 1
    gettimeofday = 2
    clock_gettime = 3

    @classmethod
    @typechecked
    def create(cls, name: str) -> 'FioClockSource':
        for item in cls:
            if item.name == name:
                return item
        raise ValueError('Enumeration FioClockSource' +
                         'Method %s' % inspect.getframeinfo(inspect.currentframe()).function +
                         'Input does not match a known type '
                         'Received: %s ' % name)

    @classmethod
    @typechecked
    def has_name(cls, name: str) -> bool:
        return any(name == item.name for item in cls)

    @classmethod
    @typechecked
    def has_value(cls, value: int) -> bool:
        return any(value == item.value for item in cls)

    @classmethod
    @typechecked
    def get_all_member(cls) -> List['FioClockSource']:
        return [item for item in cls]

    @classmethod
    @typechecked
    def get_all_name(cls) -> List[str]:
        return [item.name for item in cls]

    @classmethod
    @typechecked
    def get_all_value(cls) -> List[int]:
        return [item.value for item in cls]

    def __str__(self) -> str:
        switch = {
            FioClockSource.cpu.value: 'cpu',
            FioClockSource.gettimeofday.value: 'gettimeofday',
            FioClockSource.clock_gettime.value: 'clock_gettime',
        }
        return switch.get(self.value)

    def __repr__(self):
        return self.__str__()
