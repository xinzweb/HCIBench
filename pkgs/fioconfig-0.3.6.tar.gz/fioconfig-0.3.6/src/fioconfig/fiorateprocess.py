import inspect

from enum import Enum
from typeguard import typechecked
from typing import List


class FioRateProcess(Enum):
    """ FIO Rate Process
        Desc:   This option controls how fio manages rated I/O submissions.
                The default is linear, which submits I/O in a linear fashion with fixed delays between I/Os that gets
                adjusted based on I/O completion rates. If this is set to poisson, fio will submit I/O based on a more
                real world random request flow, known as the Poisson process.
                The lambda will be 10^6 / IOPS for the given workload.
        Values: - linear
                - poisson
        Ref.    https://fio.readthedocs.io/en/latest/fio_doc.html#time-related-parameters
                https://en.wikipedia.org/wiki/Poisson_point_process
        """
    linear = 1
    poisson = 2

    @classmethod
    @typechecked
    def create(cls, name: str) -> 'FioRateProcess':
        for item in cls:
            if item.name == name:
                return item
        raise ValueError('Enumeration FioRateProcess ' +
                         'Method %s' % inspect.getframeinfo(inspect.currentframe()).function +
                         'Input does not match a known type ' +
                         'Received %s' % name)

    @classmethod
    @typechecked
    def has_name(cls, name: str) -> bool:
        return any(name == item.name for item in cls)

    @classmethod
    @typechecked
    def has_value(cls, value: int) -> bool:
        return any(value == item.value for item in cls)

    @classmethod
    @typechecked
    def get_all_member(cls) -> List['FioRateProcess']:
        return [item for item in cls]

    @classmethod
    @typechecked
    def get_all_name(cls) -> List[str]:
        return [item.name for item in cls]

    @classmethod
    @typechecked
    def get_all_value(cls) -> List[int]:
        return [item.value for item in cls]

    def __str__(self) -> str:
        switch = {
            FioRateProcess.linear.value: 'linear',
            FioRateProcess.poisson.value: 'poisson',
        }
        return switch.get(self.value)

    def __repr__(self):
        return self.__str__()
