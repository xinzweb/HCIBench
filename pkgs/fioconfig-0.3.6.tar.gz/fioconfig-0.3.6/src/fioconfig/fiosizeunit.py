import inspect

from enum import Enum
from typeguard import typechecked
from typing import List


class FioSizeUnit(Enum):
    """ FIO Size Units
        Desc:   The optional integer suffix specifies the number’s units, and includes an optional unit prefix and
                an optional unit. For quantities of data, the default unit is bytes.

                With kb_base=1000, fio follows international standards for unit prefixes.
                To specify power-of-10 decimal values defined in the International System of Units (SI):

                K – means kilo (K) or 1000
                M – means mega (M) or 1000**2
                G – means giga (G) or 1000**3
                T – means tera (T) or 1000**4
                P – means peta (P) or 1000**5


                With kb_base=1024 (the default), the unit prefixes are opposite from those specified in the SI
                and IEC 80000-13 standards to provide compatibility with old scripts. For example, 4k means 4096.
                To specify power-of-2 binary values defined in IEC 80000-13:

                Ki – means kibi (Ki) or 1024
                Mi – means mebi (Mi) or 1024**2
                Gi – means gibi (Gi) or 1024**3
                Ti – means tebi (Ti) or 1024**4
                Pi – means pebi (Pi) or 1024**5
        Ref:    https://fio.readthedocs.io/en/latest/fio_doc.html#units
        """
    K = 1
    M = 2
    G = 3
    T = 4
    P = 5
    Ki = 6
    Mi = 7
    Gi = 8
    Ti = 9
    Pi = 10
    Percent = 11

    @classmethod
    @typechecked
    def create(cls, name: str) -> 'FioSizeUnit':

        name_orig = name

        if name == '%':
            name = 'Percent'
        else:
            name = name.lower().capitalize()

        for item in cls:
            if item.name == name:
                return item
        raise ValueError('Enumeration FioSizeUnit ' +
                         'Method %s ' % inspect.getframeinfo(inspect.currentframe()).function +
                         'Input does not match a known type' +
                         'Received: %s' % name_orig)

    @classmethod
    @typechecked
    def has_name(cls, name: str) -> bool:
        if name == '%':
            name = 'Percent'
        return any(name.upper() == item.name.upper() for item in cls)

    @classmethod
    @typechecked
    def has_value(cls, value: int) -> bool:
        return any(value == item.value for item in cls)

    @classmethod
    @typechecked
    def get_all_member(cls) -> List['FioSizeUnit']:
        return [item for item in cls]

    @classmethod
    @typechecked
    def get_all_name(cls) -> List[str]:
        return [item.name for item in cls]

    @classmethod
    @typechecked
    def get_all_value(cls) -> List[int]:
        return [item.value for item in cls]

    def __str__(self) -> str:
        switch = {
            FioSizeUnit.K.value: 'K',
            FioSizeUnit.M.value: 'M',
            FioSizeUnit.G.value: 'G',
            FioSizeUnit.T.value: 'T',
            FioSizeUnit.P.value: 'P',
            FioSizeUnit.Ki.value: 'Ki',
            FioSizeUnit.Mi.value: 'Mi',
            FioSizeUnit.Gi.value: 'Gi',
            FioSizeUnit.Ti.value: 'Ti',
            FioSizeUnit.Pi.value: 'Pi',
            FioSizeUnit.Percent.value: '%',
        }
        return switch.get(self.value)

    def __repr__(self):
        return self.__str__()
