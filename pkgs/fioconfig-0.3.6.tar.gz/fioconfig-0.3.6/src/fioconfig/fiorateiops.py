import inspect

from typeguard import typechecked
from typing import List
from typing import Union


class FioRateIops(object):

    def __init__(self, value: Union[List[int], str]):
        self.rate_iops = value

    #
    # Properties
    #

    # rate_iops
    @property
    def rate_iops(self) -> List[int]:
        return self._rate_iops

    @rate_iops.setter
    @typechecked()
    def rate_iops(self, value: Union[List[int], str]):

        self._rate_iops = []
        if isinstance(value, list):
            for item in value:
                if item < 1:
                    raise ValueError('Class FioRateIops ' +
                                     'Method %s ' % inspect.getframeinfo(inspect.currentframe()).function +
                                     'Input unit is percentage but value is out of range ' +
                                     'Expected range: [1,100] ' +
                                     'Received: %s' % item)
                self._rate_iops.append(item)
        else:
            for item in value.split(','):
                if int(item) < 1:
                    raise ValueError('Class FioRateIops ' +
                                     'Method %s ' % inspect.getframeinfo(inspect.currentframe()).function +
                                     'Input unit is percentage but value is out of range ' +
                                     'Expected range: [1,100] ' +
                                     'Received: %s' % item)
                self._rate_iops.append(int(item))

    #
    # Builtin
    #
    def __str__(self) -> str:
        value = ''
        first = True
        for item in self._rate_iops:
            if first:
                value += '%s' % item
                first = False
            else:
                value += ',%s' % item
        return value
