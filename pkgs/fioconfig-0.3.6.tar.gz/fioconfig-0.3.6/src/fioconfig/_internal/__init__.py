#!/usr/bin/env python

from fioconfig._internal.cli.commands import cli


def main():
    cli()


if __name__ == '__main__':
    main()

